# Sdk 抓取

抓取 Sdk 数据。

## Sdk 的抓取

### Sdk 抓取配置参数

打开 Start Custom Config 开关抓取 Sdk 数据。
![GitHub Logo](../../figures/sdk/sdk.jpg)
