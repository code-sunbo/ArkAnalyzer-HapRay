使用pip install安装目录下的四个pip安装包
由于存在依赖关系，请按照以下顺序安装
xdevice, xdevice-devicetest, xdevice-ohos, hypium
安装命令:
pip install xdevice-5.0.7.200.tar.gz
pip install xdevice-devicetest-5.0.7.200.tar.gz
pip install xdevice-ohos-5.0.7.200.tar.gz
pip install hypium-5.0.7.200.tar.gz
